package Product1.DataTypes;

public class Primitives {
    public static void main(String args[]) {
        int integer = 100;
        double Double = 3.142;
        float Float = 3.1414f;
        long Long = 1000000;
        boolean Boolean = false;
        char Char = 'c';

        System.out.println("Integer * Double " + integer * Double);
        System.out.println("Long + Float " + (Long + Float));
        System.out.println("Boolean " + Boolean);
        System.out.println("Char " + Char);
    }
}
