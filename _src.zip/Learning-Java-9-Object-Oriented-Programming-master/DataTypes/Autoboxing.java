package Product1.DataTypes;

public class Autoboxing {
    public static void main(String args[]) {
        Integer objectInt = 10;
        int primitiveInt = 20;

        Double objectDouble = 3.1;
        double primitiveDouble = 1.2;

        System.out.println(objectInt + primitiveInt);
        System.out.println(objectDouble + primitiveDouble);
    }
}
