package Product1.OOP;

public interface TransportInterface {
    int getMaxPassengers();

    int getMaxSpeed();

    int getNumberOfWheels();

    String getVehicleType();
}
