package Product1.JShell;

public class Loop {
    public static void main(String args[]) {
        int[] myArray = {5, 12, 13, 17, 22, 39};

        for (int value : myArray) {
            System.out.println(value);
        }
    }
}
