package Product1.JShell;

public class Maths {
    public static void main(String args[]) {
        int i = 5;
        int j = 10;
        System.out.println("Addition: " + (i + j));
        System.out.println("Subtraction: " + (i - j));
        System.out.println("Multiplication: " + (i * j));
        System.out.println("Division: " + (j / i));
    }
}
